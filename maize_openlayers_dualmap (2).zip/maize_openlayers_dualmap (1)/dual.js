const geojsonUrl = 'data.geojson';

const view = new ol.View({ center: [0, 0], zoom: 2 });
const baseLayer = new ol.layer.Tile({ source: new ol.source.OSM() });

const mapA = new ol.Map({ target: 'mapA', layers: [baseLayer], view });
const mapB = new ol.Map({ target: 'mapB', layers: [baseLayer], view });

let layerA = null;
let layerB = null;

function hexToRgb(hex) {
  const bigint = parseInt(hex.slice(1), 16);
  return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
}
function rgbToHex(r, g, b) {
  return "#" + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
}
function blendColors(hex1, hex2) {
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);
  return rgbToHex(
    Math.round((r1 + r2) / 2),
    Math.round((g1 + g2) / 2),
    Math.round((b1 + b2) / 2)
  );
}
function getBreakClass(value, breaks) {
  if (!breaks || !Array.isArray(breaks) || breaks.length < 2) return 0;
  if (value === undefined || value === null || isNaN(value)) return 0;
  for (let i = 0; i < breaks.length - 1; i++) {
    if (value >= breaks[i] && value <= breaks[i + 1]) return i;
  }
  return 0;
}

function createLayerByMode(mode, year, callback) {
  fetch(geojsonUrl)
    .then(res => res.json())
    .then(data => {
      const format = new ol.format.GeoJSON();
      const features = format.readFeatures(data, {
        featureProjection: 'EPSG:3857'
      });

      if (features.length === 0) {
        console.warn(`⚠️ No features loaded for year ${year}`);
        return callback(null);
      }

      let styleFn;

      if (mode === 'yield') {
        const field = `Yield_${year}`;
        const values = features.map(f => f.get(field)).filter(v => typeof v === 'number');
        if (!values.length) return callback(null);
        const breaks = ss.jenks(values, 6);
        const colors = ['#edf8e9','#bae4b3','#74c476','#31a354','#006d2c','#00441b'];
        styleFn = f => {
          const v = f.get(field);
          const idx = getBreakClass(v, breaks);
          return new ol.style.Style({
            fill: new ol.style.Fill({ color: colors[idx] }),
            stroke: new ol.style.Stroke({ color: '#555', width: 0.5 })
          });
        };
      }

      else if (mode === 'dotdensity') {
        const pf = `Prod_${year}`;
        const af = `Area_${year}`;
        const pvals = features.map(f => f.get(pf)).filter(v => typeof v === 'number');
        const avals = features.map(f => f.get(af)).filter(v => typeof v === 'number');
        if (!pvals.length || !avals.length) return callback(null);
        const pbreaks = ss.jenks(pvals, 10);
        const abreaks = ss.jenks(avals, 10);
        const ramp = ['#f7fbff','#deebf7','#c6dbef','#9ecae1','#6baed6',
                      '#4292c6','#2171b5','#08519c','#08306b','#041f49'];
        styleFn = f => {
          const p = f.get(pf), a = f.get(af);
          const pc = getBreakClass(p, pbreaks);
          const ac = getBreakClass(a, abreaks);
          return new ol.style.Style({
            image: new ol.style.Circle({
              radius: 3 + ac * 0.7,
              fill: new ol.style.Fill({ color: ramp[pc] }),
              stroke: new ol.style.Stroke({ color: '#222', width: 0.3 })
            })
          });
        };
      }

      else if (mode === 'bivariate') {
        const pf = `Prod_${year}`;
        const af = `Area_${year}`;
        const pvals = features.map(f => f.get(pf)).filter(v => typeof v === 'number');
        const avals = features.map(f => f.get(af)).filter(v => typeof v === 'number');
        if (!pvals.length || !avals.length) return callback(null);
        const pbreaks = ss.jenks(pvals, 5);
        const abreaks = ss.jenks(avals, 5);
        const pcolors = ['#edf8e9','#bae4b3','#74c476','#31a354','#006d2c'];
        const acolors = ['#fff5eb','#fee6ce','#fdae6b','#e6550d','#a63603'];
        const showArea = document.getElementById('showArea').checked;
        const showProd = document.getElementById('showProd').checked;
        styleFn = f => {
          const a = f.get(af), p = f.get(pf);
          const ai = getBreakClass(a, abreaks);
          const pi = getBreakClass(p, pbreaks);
          let color = '#ccc';
          if (showArea && showProd) color = blendColors(acolors[ai], pcolors[pi]);
          else if (showArea) color = acolors[ai];
          else if (showProd) color = pcolors[pi];
          return new ol.style.Style({
            fill: new ol.style.Fill({ color }),
            stroke: new ol.style.Stroke({ color: '#444', width: 0.5 })
          });
        };
      }

      const vectorLayer = new ol.layer.Vector({
        source: new ol.source.Vector({ features }),
        style: styleFn
      });

      callback(vectorLayer);
    })
    .catch(err => {
      console.error("Error loading GeoJSON:", err);
      callback(null);
    });
}

// ✅ SAFE updateMaps function
function updateMaps() {
  const mode = document.getElementById('mapMode').value;
  const yearA = document.getElementById('yearA').value;
  const yearB = document.getElementById('yearB').value;

  document.getElementById('yearLabelA').innerText = yearA;
  document.getElementById('yearLabelB').innerText = yearB;

  if (layerA) { mapA.removeLayer(layerA); layerA = null; }
  if (layerB) { mapB.removeLayer(layerB); layerB = null; }

  createLayerByMode(mode, yearA, layer => {
    if (layer) {
      layerA = layer;
      mapA.addLayer(layerA);
      console.log(`✅ Map A (${yearA}) loaded`);
    } else {
      console.warn(`⚠️ Map A (${yearA}) failed to load`);
    }
  });

  createLayerByMode(mode, yearB, layer => {
    if (layer) {
      layerB = layer;
      mapB.addLayer(layerB);
      console.log(`✅ Map B (${yearB}) loaded`);
    } else {
      console.warn(`⚠️ Map B (${yearB}) failed to load`);
    }
  });
}

// Tooltip logic
const tooltip = document.getElementById('tooltip');
function setupTooltip(map, id) {
  map.on('pointermove', function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, f => f);
    if (feature) {
      const props = feature.getProperties();
      const year = document.getElementById(id === 'mapA' ? 'yearA' : 'yearB').value;
      tooltip.style.left = evt.originalEvent.pageX + 10 + 'px';
      tooltip.style.top = evt.originalEvent.pageY + 10 + 'px';
      tooltip.innerHTML = `<strong>${props.Country || props.ADMIN}</strong><br/>
        Area: ${props['Area_' + year] || '–'}<br/>
        Prod: ${props['Prod_' + year] || '–'}<br/>
        Yield: ${props['Yield_' + year] || '–'}`;
      tooltip.style.display = 'block';
    } else {
      tooltip.style.display = 'none';
    }
  });
}
setupTooltip(mapA, 'mapA');
setupTooltip(mapB, 'mapB');

// Event bindings
document.getElementById('mapMode').addEventListener('change', updateMaps);
document.getElementById('yearA').addEventListener('input', updateMaps);
document.getElementById('yearB').addEventListener('input', updateMaps);
document.getElementById('showArea').addEventListener('change', updateMaps);
document.getElementById('showProd').addEventListener('change', updateMaps);

// Initial load
updateMaps();
