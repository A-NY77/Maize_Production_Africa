// legend.js – handles static yield legend and dynamic bivariate 5x5 matrix

function renderYieldLegend(containerId) {
  const container = document.getElementById(containerId);
  container.innerHTML = `
    <div><strong>Yield (kg/ha)</strong></div>
    <div style="margin-top: 5px;">
      <div style="background:#edf8e9; height:20px;">0–1500</div>
      <div style="background:#bae4b3; height:20px;">1500–2500</div>
      <div style="background:#74c476; height:20px;">2500–3500</div>
      <div style="background:#31a354; height:20px;">3500–4500</div>
      <div style="background:#006d2c; height:20px;">4500–5500</div>
      <div style="background:#00441b; height:20px;">5500+</div>
    </div>
  `;
}

function renderBivariateMatrix(containerId, showProd, showArea) {
  const container = document.getElementById(containerId);
  const pColors = ['#edf8e9','#bae4b3','#74c476','#31a354','#006d2c'];
  const aColors = ['#fff5eb','#fee6ce','#fdae6b','#e6550d','#a63603'];

  container.innerHTML = `<div><strong>Bivariate Matrix</strong></div><table style="border-collapse: collapse; margin-top: 5px;"></table>`;
  const table = container.querySelector('table');

  for (let r = 4; r >= 0; r--) {
    const row = document.createElement('tr');
    for (let c = 0; c < 5; c++) {
      const cell = document.createElement('td');
      cell.style.width = '20px';
      cell.style.height = '20px';
      cell.style.border = '1px solid #ccc';
      if (showArea && showProd) {
        cell.style.backgroundColor = blendColors(aColors[r], pColors[c]);
      } else if (showArea) {
        cell.style.backgroundColor = aColors[r];
      } else if (showProd) {
        cell.style.backgroundColor = pColors[c];
      } else {
        cell.style.backgroundColor = '#eee';
      }
      row.appendChild(cell);
    }
    table.appendChild(row);
  }
}

function blendColors(hex1, hex2) {
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);
  return rgbToHex(
    Math.round((r1 + r2) / 2),
    Math.round((g1 + g2) / 2),
    Math.round((b1 + b2) / 2)
  );
}

function hexToRgb(hex) {
  const bigint = parseInt(hex.slice(1), 16);
  return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
}

function rgbToHex(r, g, b) {
  return "#" + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
}
